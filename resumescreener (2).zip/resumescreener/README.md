# Resume Screener

A simple resume screening bot built with Python (Flask) using NLP keyword matching.

## How it works
1. Enter the required keywords (comma separated)
2. Upload one or more resumes (PDF or TXT)
3. Text is cleaned (lowercase, punctuation and stopwords removed)
4. Each keyword is matched against the resume
5. Score = matched keywords / total keywords x 100, resumes ranked best first

## Run locally
```
pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:5000

## Tech
Python, Flask, pypdf, HTML/CSS
