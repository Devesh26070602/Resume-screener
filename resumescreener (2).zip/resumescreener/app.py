"""
Resume Screening Bot - simple NLP keyword matching
Run:  python app.py   then open http://127.0.0.1:5000
"""
import re
from flask import Flask, render_template_string, request
from pypdf import PdfReader

app = Flask(__name__)

# Common words that carry no meaning for matching (a tiny stopword list)
STOPWORDS = {
    "a", "an", "the", "and", "or", "of", "to", "in", "on", "for", "with",
    "is", "are", "was", "were", "at", "by", "from", "as", "that", "this",
}


# ---------- Step 1: read the resume ----------
def read_resume(file):
    """Return plain text from a PDF or TXT upload."""
    if file.filename.lower().endswith(".pdf"):
        reader = PdfReader(file)
        return " ".join(page.extract_text() or "" for page in reader.pages)
    return file.read().decode("utf-8", errors="ignore")


# ---------- Step 2: clean the text (basic NLP preprocessing) ----------
def clean_text(text):
    text = text.lower()                          # lowercase
    text = re.sub(r"[^a-z0-9+#.\s]", " ", text)  # drop punctuation (keep c++, c#, node.js)
    words = [w for w in text.split() if w not in STOPWORDS]  # remove stopwords
    return " " + " ".join(words) + " "           # padded so whole-word match works


# ---------- Step 3: keyword matching ----------
def score_resume(resume_text, keywords):
    cleaned = clean_text(resume_text)
    matched, missing = [], []
    for kw in keywords:
        if " " + clean_text(kw).strip() + " " in cleaned:
            matched.append(kw)
        else:
            missing.append(kw)
    score = round(len(matched) / len(keywords) * 100) if keywords else 0
    return score, matched, missing


# ---------- The web page (HTML) ----------
PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Resume Screening Bot</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; padding: 20px; color: #222; }
    .box { max-width: 720px; margin: auto; background: #fff; padding: 24px; border-radius: 8px; box-shadow: 0 1px 4px rgba(0,0,0,.1); }
    h1 { margin-top: 0; }
    label { display: block; margin: 16px 0 6px; font-weight: bold; }
    input[type=text] { width: 100%; padding: 10px; box-sizing: border-box; border: 1px solid #bbb; border-radius: 4px; }
    button { margin-top: 18px; padding: 10px 22px; background: #2563eb; color: #fff; border: 0; border-radius: 4px; font-size: 16px; cursor: pointer; }
    .error { color: #b91c1c; margin-top: 12px; }
    table { width: 100%; border-collapse: collapse; margin-top: 24px; }
    th, td { text-align: left; padding: 10px; border-bottom: 1px solid #ddd; vertical-align: top; }
    .good { color: #15803d; }
    .bad { color: #b91c1c; }
    .bar { background: #e5e7eb; border-radius: 4px; height: 10px; width: 100px; }
    .bar div { background: #2563eb; height: 10px; border-radius: 4px; }
  </style>
</head>
<body>
  <div class="box">
    <h1>Resume Screening Bot</h1>
    <p>Enter the skills you need, upload resumes, and see who matches best.</p>

    <form method="POST" enctype="multipart/form-data">
      <label for="keywords">Required keywords (comma separated)</label>
      <input type="text" id="keywords" name="keywords" placeholder="python, sql, machine learning, flask">

      <label for="resumes">Upload resumes (PDF or TXT)</label>
      <input type="file" id="resumes" name="resumes" accept=".pdf,.txt" multiple>

      <button type="submit">Screen Resumes</button>
    </form>

    {% if error %}<p class="error">{{ error }}</p>{% endif %}

    {% if results %}
    <table>
      <tr><th>Rank</th><th>Resume</th><th>Score</th><th>Keywords</th></tr>
      {% for r in results %}
      <tr>
        <td>{{ loop.index }}</td>
        <td>{{ r.name }}</td>
        <td>
          {{ r.score }}%
          <div class="bar"><div style="width: {{ r.score }}%"></div></div>
        </td>
        <td>
          <span class="good">✔ {{ r.matched | join(", ") or "none" }}</span><br>
          <span class="bad">✘ {{ r.missing | join(", ") or "none" }}</span>
        </td>
      </tr>
      {% endfor %}
    </table>
    {% endif %}
  </div>
</body>
</html>
"""


# ---------- Web routes ----------
@app.route("/", methods=["GET", "POST"])
def index():
    results = []
    error = None
    if request.method == "POST":
        raw = request.form.get("keywords", "")
        keywords = [k.strip() for k in raw.split(",") if k.strip()]
        files = [f for f in request.files.getlist("resumes") if f.filename]

        if not keywords:
            error = "Please enter at least one keyword."
        elif not files:
            error = "Please upload at least one resume."
        else:
            for f in files:
                text = read_resume(f)
                score, matched, missing = score_resume(text, keywords)
                results.append({"name": f.filename, "score": score,
                                "matched": matched, "missing": missing})
            results.sort(key=lambda r: r["score"], reverse=True)  # best first
    return render_template_string(PAGE, results=results, error=error)


if __name__ == "__main__":
    app.run(debug=True)
